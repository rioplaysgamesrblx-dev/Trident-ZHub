import { useState } from "react";
import { Zap, Eye, Settings, Globe, Crosshair, Sliders, Palette, ToggleRight } from "lucide-react";

export default function Index() {
  const [activeTab, setActiveTab] = useState("combat");
  const [aimbotEnabled, setAimbotEnabled] = useState(false);
  const [espEnabled, setEspEnabled] = useState(false);
  const [fovSize, setFovSize] = useState(50);
  const [smoothness, setSmoothness] = useState(5);
  const [freecamEnabled, setFreecamEnabled] = useState(false);
  const [timeEnabled, setTimeEnabled] = useState(false);
  const [time, setTime] = useState(12);

  const [hitboxExpander, setHitboxExpander] = useState(false);
  const [hitboxSizeX, setHitboxSizeX] = useState(3);
  const [hitboxSizeY, setHitboxSizeY] = useState(3);

  const [crosshairEnabled, setCrosshairEnabled] = useState(false);
  const [crosshairColor, setCrosshairColor] = useState("#00d9ff");

  const tabs = [
    { id: "combat", label: "COMBAT", icon: Zap },
    { id: "visuals", label: "VISUALS", icon: Eye },
    { id: "world", label: "WORLD", icon: Globe },
    { id: "misc", label: "MISC", icon: Settings },
  ];

  const Toggle = ({ 
    label, 
    value, 
    onChange 
  }: { 
    label: string; 
    value: boolean; 
    onChange: (val: boolean) => void 
  }) => (
    <div className="flex items-center justify-between py-3 px-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors border border-white/10">
      <span className="text-sm font-medium text-gray-300">{label}</span>
      <button
        onClick={() => onChange(!value)}
        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-all ${
          value ? "bg-neon-cyan shadow-lg shadow-neon-cyan/50" : "bg-white/10"
        }`}
      >
        <span
          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
            value ? "translate-x-6" : "translate-x-1"
          }`}
        />
      </button>
    </div>
  );

  const Slider = ({
    label,
    value,
    onChange,
    min = 0,
    max = 100,
    unit = "",
  }: {
    label: string;
    value: number;
    onChange: (val: number) => void;
    min?: number;
    max?: number;
    unit?: string;
  }) => (
    <div className="py-3 px-4 rounded-lg bg-white/5 border border-white/10">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium text-gray-300">{label}</span>
        <span className="text-xs font-semibold text-neon-cyan">
          {value}
          {unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full h-2 bg-white/10 rounded-lg appearance-none cursor-pointer accent-neon-cyan"
      />
    </div>
  );

  const Section = ({
    title,
    children,
  }: {
    title: string;
    children: React.ReactNode;
  }) => (
    <div className="space-y-2">
      <h3 className="text-xs font-bold uppercase tracking-wider text-neon-cyan px-4 pt-2">
        {title}
      </h3>
      <div className="space-y-2">{children}</div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 text-white overflow-hidden">
      {/* Animated background */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-neon-cyan/10 rounded-full blur-3xl opacity-20" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl opacity-20" />
      </div>

      {/* Main container */}
      <div className="relative z-10">
        {/* Header */}
        <div className="border-b border-white/10 bg-black/20 backdrop-blur-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-black bg-gradient-to-r from-neon-cyan via-purple-400 to-pink-400 bg-clip-text text-transparent">
                  TRIDENT ZHUB
                </h1>
                <p className="text-xs text-gray-400 mt-1">Advanced Control Panel • v1.0</p>
              </div>
              <div className="flex gap-2">
                <div className="px-3 py-1.5 rounded-full bg-neon-cyan/20 border border-neon-cyan/50 text-xs font-semibold text-neon-cyan">
                  ONLINE
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Tab Navigation */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative px-4 py-3 rounded-lg font-semibold text-sm transition-all flex items-center justify-center gap-2 group ${
                    activeTab === tab.id
                      ? "bg-gradient-to-r from-neon-cyan to-cyan-400 text-black shadow-lg shadow-neon-cyan/50"
                      : "bg-white/5 text-gray-300 border border-white/10 hover:bg-white/10 hover:border-neon-cyan/30"
                  }`}
                >
                  <Icon size={16} />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Tab Content */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Panel */}
            <div className="lg:col-span-2 space-y-6">
              {/* Combat Tab */}
              {activeTab === "combat" && (
                <div className="space-y-6">
                  {/* Aimbot Section */}
                  <div className="p-6 rounded-xl bg-gradient-to-br from-white/10 to-white/5 border border-white/20 backdrop-blur-xl">
                    <div className="flex items-center gap-3 mb-4">
                      <Crosshair className="text-neon-cyan" size={20} />
                      <h2 className="text-lg font-bold">AIMBOT</h2>
                    </div>
                    <div className="space-y-3">
                      <Toggle
                        label="Enable Aimbot"
                        value={aimbotEnabled}
                        onChange={setAimbotEnabled}
                      />
                      {aimbotEnabled && (
                        <>
                          <Slider
                            label="FOV Size"
                            value={fovSize}
                            onChange={setFovSize}
                            min={10}
                            max={100}
                          />
                          <Slider
                            label="Smoothness"
                            value={smoothness}
                            onChange={setSmoothness}
                            min={1}
                            max={10}
                          />
                          <Toggle label="Sleeper Check" value={false} onChange={() => {}} />
                          <Toggle label="Bot Check" value={false} onChange={() => {}} />
                          <Toggle label="Wall Check" value={false} onChange={() => {}} />
                        </>
                      )}
                    </div>
                  </div>

                  {/* Hitbox Section */}
                  <div className="p-6 rounded-xl bg-gradient-to-br from-white/10 to-white/5 border border-white/20 backdrop-blur-xl">
                    <div className="flex items-center gap-3 mb-4">
                      <Sliders className="text-neon-cyan" size={20} />
                      <h2 className="text-lg font-bold">HITBOX</h2>
                    </div>
                    <div className="space-y-3">
                      <Toggle
                        label="Hitbox Expander"
                        value={hitboxExpander}
                        onChange={setHitboxExpander}
                      />
                      {hitboxExpander && (
                        <>
                          <Slider
                            label="Size X"
                            value={hitboxSizeX}
                            onChange={setHitboxSizeX}
                            min={2}
                            max={6}
                          />
                          <Slider
                            label="Size Y"
                            value={hitboxSizeY}
                            onChange={setHitboxSizeY}
                            min={2}
                            max={6}
                          />
                          <Toggle label="Can Collide" value={false} onChange={() => {}} />
                          <Toggle label="Sleeper Check" value={false} onChange={() => {}} />
                        </>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Visuals Tab */}
              {activeTab === "visuals" && (
                <div className="space-y-6">
                  {/* ESP Section */}
                  <div className="p-6 rounded-xl bg-gradient-to-br from-white/10 to-white/5 border border-white/20 backdrop-blur-xl">
                    <div className="flex items-center gap-3 mb-4">
                      <Eye className="text-neon-cyan" size={20} />
                      <h2 className="text-lg font-bold">PLAYER ESP</h2>
                    </div>
                    <div className="space-y-3">
                      <Toggle
                        label="Enable ESP"
                        value={espEnabled}
                        onChange={setEspEnabled}
                      />
                      {espEnabled && (
                        <>
                          <Toggle label="Info ESP" value={false} onChange={() => {}} />
                          <Toggle label="Chams ESP" value={false} onChange={() => {}} />
                          <Toggle label="Check Sleeper" value={false} onChange={() => {}} />
                          <Toggle label="Check Bot" value={false} onChange={() => {}} />
                          <Slider
                            label="Max Distance"
                            value={1000}
                            onChange={() => {}}
                            max={1000}
                            unit=" studs"
                          />
                        </>
                      )}
                    </div>
                  </div>

                  {/* Crosshair Section */}
                  <div className="p-6 rounded-xl bg-gradient-to-br from-white/10 to-white/5 border border-white/20 backdrop-blur-xl">
                    <div className="flex items-center gap-3 mb-4">
                      <Palette className="text-neon-cyan" size={20} />
                      <h2 className="text-lg font-bold">CROSSHAIR</h2>
                    </div>
                    <div className="space-y-3">
                      <Toggle
                        label="Enable Crosshair"
                        value={crosshairEnabled}
                        onChange={setCrosshairEnabled}
                      />
                      {crosshairEnabled && (
                        <>
                          <div className="py-3 px-4 rounded-lg bg-white/5 border border-white/10">
                            <label className="text-sm font-medium text-gray-300 block mb-2">
                              Crosshair Color
                            </label>
                            <div className="flex gap-2">
                              <input
                                type="color"
                                value={crosshairColor}
                                onChange={(e) => setCrosshairColor(e.target.value)}
                                className="h-10 w-16 rounded cursor-pointer"
                              />
                              <div className="flex-1 flex items-center px-3 bg-white/5 rounded border border-white/10 text-xs text-gray-400">
                                {crosshairColor}
                              </div>
                            </div>
                          </div>
                          <Slider
                            label="Thickness"
                            value={2}
                            onChange={() => {}}
                            min={2}
                            max={6}
                            unit=" px"
                          />
                          <Slider
                            label="Length"
                            value={8}
                            onChange={() => {}}
                            min={4}
                            max={20}
                            unit=" px"
                          />
                        </>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* World Tab */}
              {activeTab === "world" && (
                <div className="space-y-6">
                  <div className="p-6 rounded-xl bg-gradient-to-br from-white/10 to-white/5 border border-white/20 backdrop-blur-xl">
                    <div className="flex items-center gap-3 mb-4">
                      <Globe className="text-neon-cyan" size={20} />
                      <h2 className="text-lg font-bold">WORLD</h2>
                    </div>
                    <div className="space-y-3">
                      <Toggle
                        label="Time Changer"
                        value={timeEnabled}
                        onChange={setTimeEnabled}
                      />
                      {timeEnabled && (
                        <Slider
                          label="Time of Day"
                          value={time}
                          onChange={setTime}
                          min={0}
                          max={24}
                        />
                      )}
                      <Toggle label="Stone ESP" value={false} onChange={() => {}} />
                      <Toggle label="Iron ESP" value={false} onChange={() => {}} />
                      <Toggle label="Nitrate ESP" value={false} onChange={() => {}} />
                      <Slider
                        label="Ore Max Distance"
                        value={500}
                        onChange={() => {}}
                        min={100}
                        max={1000}
                        unit=" studs"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Misc Tab */}
              {activeTab === "misc" && (
                <div className="space-y-6">
                  <div className="p-6 rounded-xl bg-gradient-to-br from-white/10 to-white/5 border border-white/20 backdrop-blur-xl">
                    <div className="flex items-center gap-3 mb-4">
                      <Settings className="text-neon-cyan" size={20} />
                      <h2 className="text-lg font-bold">MISC</h2>
                    </div>
                    <div className="space-y-3">
                      <Toggle
                        label="Enable Freecam"
                        value={freecamEnabled}
                        onChange={setFreecamEnabled}
                      />
                      {freecamEnabled && (
                        <>
                          <Slider
                            label="Freecam Speed"
                            value={5}
                            onChange={() => {}}
                            min={1}
                            max={20}
                          />
                          <div className="py-3 px-4 rounded-lg bg-white/5 border border-white/10">
                            <label className="text-sm font-medium text-gray-300 block mb-2">
                              Freecam Bind: X
                            </label>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Right Sidebar - Stats & Info */}
            <div className="space-y-6">
              {/* Status Panel */}
              <div className="p-6 rounded-xl bg-gradient-to-br from-white/10 to-white/5 border border-white/20 backdrop-blur-xl">
                <h3 className="text-sm font-bold uppercase tracking-wider text-neon-cyan mb-4">
                  STATUS
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between py-2 border-b border-white/10">
                    <span className="text-sm text-gray-400">Connection</span>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-neon-cyan animate-pulse" />
                      <span className="text-xs font-semibold text-neon-cyan">ACTIVE</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between py-2 border-b border-white/10">
                    <span className="text-sm text-gray-400">Features Active</span>
                    <span className="text-sm font-semibold text-gray-200">
                      {[
                        aimbotEnabled,
                        espEnabled,
                        hitboxExpander,
                        freecamEnabled,
                        crosshairEnabled,
                      ].filter(Boolean).length}
                    </span>
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <span className="text-sm text-gray-400">Version</span>
                    <span className="text-sm font-semibold text-gray-200">1.0</span>
                  </div>
                </div>
              </div>

              {/* Active Features */}
              <div className="p-6 rounded-xl bg-gradient-to-br from-white/10 to-white/5 border border-white/20 backdrop-blur-xl">
                <h3 className="text-sm font-bold uppercase tracking-wider text-neon-cyan mb-4">
                  ACTIVE
                </h3>
                <div className="space-y-2">
                  {aimbotEnabled && (
                    <div className="flex items-center gap-2 py-2 px-3 rounded bg-neon-cyan/20 border border-neon-cyan/50">
                      <div className="w-2 h-2 rounded-full bg-neon-cyan" />
                      <span className="text-xs font-semibold text-neon-cyan">AIMBOT</span>
                    </div>
                  )}
                  {espEnabled && (
                    <div className="flex items-center gap-2 py-2 px-3 rounded bg-purple-500/20 border border-purple-500/50">
                      <div className="w-2 h-2 rounded-full bg-purple-400" />
                      <span className="text-xs font-semibold text-purple-300">ESP</span>
                    </div>
                  )}
                  {hitboxExpander && (
                    <div className="flex items-center gap-2 py-2 px-3 rounded bg-pink-500/20 border border-pink-500/50">
                      <div className="w-2 h-2 rounded-full bg-pink-400" />
                      <span className="text-xs font-semibold text-pink-300">HITBOX</span>
                    </div>
                  )}
                  {freecamEnabled && (
                    <div className="flex items-center gap-2 py-2 px-3 rounded bg-orange-500/20 border border-orange-500/50">
                      <div className="w-2 h-2 rounded-full bg-orange-400" />
                      <span className="text-xs font-semibold text-orange-300">FREECAM</span>
                    </div>
                  )}
                  {crosshairEnabled && (
                    <div className="flex items-center gap-2 py-2 px-3 rounded bg-green-500/20 border border-green-500/50">
                      <div className="w-2 h-2 rounded-full bg-green-400" />
                      <span className="text-xs font-semibold text-green-300">CROSSHAIR</span>
                    </div>
                  )}
                  {![
                    aimbotEnabled,
                    espEnabled,
                    hitboxExpander,
                    freecamEnabled,
                    crosshairEnabled,
                  ].some(Boolean) && (
                    <p className="text-xs text-gray-400 italic">No features active</p>
                  )}
                </div>
              </div>

              {/* Emergency Stop */}
              <button className="w-full py-3 rounded-lg bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 font-bold text-sm transition-all shadow-lg hover:shadow-red-600/50">
                UNLOAD (End Key)
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
